<?php global $picklepower; ?>
<footer>
	<div class="container">
		<div class="row row-centered">
			<div class="col-md-12 col-centered">
				<ul class="social-media">
					<?php 
                        if($picklepower['facebook'])    {             
                            echo '<li><a href="'.$picklepower['facebook'].'" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i><p>Facebook</p></a></li>';
                        }
                        else
                        {
                            echo "";
                        }
                     
                        if($picklepower['twitter'])
                        {
                            echo '<li><a href="'. $picklepower['twitter'] .'" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i><p>Twitter</p></a></li>';
                        }
                        else
                        {
                            echo '';
                        }
                        if($picklepower['instagram'])
                        {
                            echo '<li><a href="'. $picklepower['instagram'] .'" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i><p>Instagram</p></a></li>';
                        }
                        else
                        {
                            echo '';
                        }
                        if($picklepower['linkedin'])
                        {
                            echo '<li><a href="'. $picklepower['linkedin'] .'" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i><p>Linkedin</p></a></li>';
                        }
                        else
                        {
                            echo '';
                        }
                        if($picklepower['event-calender'])
                        {
                            echo '<li><a href="'. $picklepower['event-calender'] .'" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i><p>Event Calender</p></a></li>';
                        }
                        else
                        {
                            echo '';
                        }
                        if($picklepower['contact-us'])
                        {
                            echo '<li><a href="'. $picklepower['contact-us'] .'" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i><p>Contact Us</p></a></li>';
                        }
                        else
                        {
                            echo '';
                        }
                    ?>
                    <!-- <li><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i><p>Facebook</p></a></li> -->
					<!-- <li><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i><p>Twitter</p></a></li> -->
					<!-- <li><a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i><p>Instagram</p></a></li> -->
					<!-- <li><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i><p>Linkedin</p></a></li> -->
					<!-- <li><a href="#" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i><p>Event Calender</p></a></li> -->
					<!-- <li><a href="#" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i><p>Contact Us</p></a></li> -->
				</ul>
			</div>
		</div>
	</div> <!-- Container -->
	<div class="footer-top">
		<div class="container">
			<!-- Footer Bottom -->
		<div class="row">
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <?php dynamic_sidebar( 'footer-1' ); ?>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <?php dynamic_sidebar( 'footer-2' ); ?>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <?php dynamic_sidebar( 'footer-3' ); ?>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <?php dynamic_sidebar( 'footer-4' ); ?>
                </div>
                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-12 footer-widget">
                    <?php dynamic_sidebar( 'mail-subscription' ); ?>
                    <ul class="social">
                        <?php 
                            if($picklepower['facebook'])
                            {
                                echo '<li><a href="'.$picklepower['facebook'].'" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                            if($picklepower['twitter'])
                            {
                                echo '<li><a href="'.$picklepower['twitter'].'" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                            if($picklepower['instagram'])
                            {
                                echo '<li><a href="'.$picklepower['instagram'].'" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                            if($picklepower['linkedin'])
                            {
                                echo '<li><a href="'.$picklepower['linkedin'].'" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                            if($picklepower['event-calender'])
                            {
                                echo '<li><a href="'.$picklepower['event-calender'].'" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                            if($picklepower['contact-us'])
                            {
                                echo '<li><a href="'.$picklepower['contact-us'].'" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i></a></li>';
                            }
                            else
                            {
                                echo '';
                            }
                        ?>
                        <!-- <li><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i></a></li> -->
                    </ul>
                </div>
            </div> <!-- Row -->
            <!-- Footer Bottom End -->
		</div>
	</div>
	<div class="footer-bottom">
        <div class="container">
            <p class="col-md-4 pull-left"><?php echo $picklepower ['copyright']; ?> <?php echo date("Y"); ?></p>
            <div class="col-md-4 middle-block">
                <ul class="nav nav-pills payments">
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul></div>
            <div class="col-md-4 pull-right designed">
                 <a href="http://www.goigi.com" target="_blank">Designed &amp; Developed by GOIGI</a>
            </div>
        </div>
    </div>
</footer>
<div class="buy-now"><a href="<?php echo esc_url( home_url( '/' ) ); ?>shop"><img src="<?php bloginfo(template_url); ?>/assets/img/buy-now.png" alt=""></a></div>

</div><!-- Body Bg -->



<script src="<?php bloginfo(template_url); ?>/assets/js/jquery.min.js"></script>
<scrpt src="<?php bloginfo(template_url); ?>/assets/js/lightbox-plus-jquery.min.js"></scrpt>
<script src="<?php bloginfo(template_url); ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php bloginfo(template_url); ?>/assets/js/custom_js.js"></script>
<?php wp_footer(); ?>

<?php
    // if(is_product())
    // {
    //     //echo '<META HTTP-EQUIV="REFRESH" CONTENT="-1">' ;
    
    //     echo '<script type="text/javascript">
    //         (function()
    //             {
    //               if( window.localStorage )
    //               {
    //                 if( !localStorage.getItem( "firstLoad" ) )
    //                 {
    //                   localStorage[ "firstLoad" ] = true;
    //                   window.location.reload();
    //                 }
    //                 else
    //                   localStorage.removeItem( "firstLoad" );
    //               }
    //             })();
    //     </script>';
    // }
?>

</body>
</html>