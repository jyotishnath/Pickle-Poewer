<?php 
	/*
	*Template Name: About
	*/

	//Header
	get_header();
?>

<div class="container-fluid no-pading page-banner">
	<a href="javascript:void(0);">
		<?php 
			if(get_field("page_header_image")){				
				echo '<img src="'. get_field("page_header_image").'" alt="">' ;
			}
			else
			{
				echo "";
			}
		?>
	</a>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg page-content">
			<!-- Loop -->
			<?php
				if ( have_posts() ) {
					while ( have_posts() ) {
						the_post(); 
							?>
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home /</a></li>
					<li><?php the_title(); ?></li>
				</ul>
			</div>
			<h1><?php the_title(); ?></h1>
				<?php the_content(); ?>
			<?php 
				} // end while
					} // end if
						?>
			<!-- End Loop -->
		</div>
	</div>
</div>

<?php
	//Footer
	get_footer();
?>