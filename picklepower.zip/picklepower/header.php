<!DOCTYPE html>
<html>
<head>
	<?php global $picklepower; ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Pickle Power | <?php wp_title(); ?></title>
	<!-- Stylesheet -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/style.css">
	<!-- Custom Css -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/assets/css/custom_css.css">
	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/assets/css/bootstrap.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/assets/css/animate.css">
	<!-- Font-Awesome -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/assets/css/font-awesome.min.css">
	<!-- Image Gallery -->
	<link rel="stylesheet" href="<?php bloginfo(template_url); ?>/assets/css/lightbox.min.css">
	<!-- Titillium Web font -->
	<link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="<?php echo $picklepower ['favicon']['url']; ?>">
	<style type="text/css">
	/*Navigation Custom*/
	@media (max-width: 2000px) {
		.navbar { 
			margin-bottom: 0 !important;
			/*background: #000;*/
		}
	    .navbar-header {
	        float: none;
	    }
	    .navbar-left,.navbar-right {
	        float: none !important;
	    }
	    .navbar-toggle {
	        display: block;
		    position: absolute;
		    right: 15%;
		    top: 36%;
		    padding: 33px;
	    }
	    .navbar-collapse {
	        border-top: 1px solid transparent;
	        box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
	    }
	    .navbar-fixed-top {
	        top: 0;
	        border-width: 0 0 1px;
	    }
	    .navbar-collapse.collapse {
	        display: none!important;
	    }
	    .navbar-nav {
	        float: none!important;
	        margin-top: 7.5px;
	    }
	    .navbar-nav>li {
	        float: none;
	    }
	    .navbar-nav>li>a {
	        padding-top: 10px;
		    padding-bottom: 17px;
		    color: #fff;
		    font-size: 2em;
	    }
	    .collapse.in{
	        display:block !important;
	        position: absolute;
	        background: rgba(0, 0, 0, 0.84);
	    }
	}
	</style>
	<?php wp_head(); ?>
</head>
<body>

<div class="body-bg">
<!-- Navigation Start-->
<nav class="navbar navbar-fixed-top" >
  <div class="navbar-header">
  	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo $picklepower ['header_logo']['url']; ?>" alt="Pickle Power"></a>
  	<div class="shoping-cart">
  		<ul>
  			<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>my-account"><i class="fa fa-lock" aria-hidden="true"></i> My Account</a></li>
  			<i class="fa fa-shopping-cart" aria-hidden="true"></i>
  			<li class="cart-item" >0 items - $0.00</li>
  			<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>cart"><i class="fa fa-cart-plus" aria-hidden="true"></i> Checkout</a></li>
  			<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>my-account"><i class="fa fa-sign-in" aria-hidden="true"></i> Signin</a></li>
  		</ul>
  	</div>
    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  </div>
  
  	 <?php
            wp_nav_menu( array(
                'menu'              => 'primary',
                'theme_location'    => 'primary',
                'depth'             => 2,
                'container'         => 'div',
                'container_class'   => 'navbar-collapse collapse',
        		'container_id'      => 'nav-toggle',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                'walker'            => new wp_bootstrap_navwalker())
            );
        ?>
        <!-- <div class="navbar-collapse collapse">
    <ul class="nav navbar-nav">
      <li class="active"><a href="index">Home</a></li>
      <li class="dropdown-submenu">
      	<a class="test" tabindex="1" href="">About<span class="caret"></span></a>
      	<ul class="dropdown-menu">
      		<li><a tabindex="-1" href="about">About Us</a></li>
      		<li><a tabindex="-1" href="history">History</a></li>
      		<li><a tabindex="-1" href="media-press">Media / Press</a></li>
      		<li><a tabindex="-1" href="mission-statement">Mission Statement</a></li>
      		<li><a tabindex="-1" href="faq">Faq</a></li>
      	</ul>
      </li>
      <li class="dropdown-submenu">
		<a class="test" tabindex="-1" href="">The Product<span class="caret"></span></a>
		<ul class="dropdown-menu">
      		<li><a tabindex="-1" href="ingredients">Ingredients</a></li>
      		<li><a tabindex="-1" href="scientific-study">Scientific Study</a></li>
      		<li><a tabindex="-1" href="storage-recommendations">Storage Recommendations</a></li>
      	</ul>
      </li>
      <li><a href="shop">Shop</a></li>
      <li><a href="gallery">Gallery</a></li>
      <li class="dropdown-submenu">
		<a class="test" tabindex="-1" href="">Regulatory Information<span class="caret"></span></a>
		<ul class="dropdown-menu">
			<li><a tabindex="-1" href="regulatory-information">Regulatory Information</a></li>
      		<li><a tabindex="-1" href="process-authority">Process Authority and Regulation</a></li>
      		<li><a tabindex="-1" href="privacy-policy">Privacy Policy</a></li>
      		<li><a tabindex="-1" href="internet-sales-refund-policy">Internet Sales Refund Policy</a></li>
      		<li><a tabindex="-1" href="advice-disclaimer">Advice Disclaimer</a></li>
      	</ul>
      </li>
       <li><a href="contact-us">Contact Us</a></li> 
    </ul>
  </div> -->
</nav>
<!-- Navigation End -->