<?php 
	//Header
	include('header.php'); 
?>

<?php
	//Carousel
	include('carosal.php');

	//Product Carousel
	echo '<div class="container">
	  <div class="row">
	    <h2 class="sec_head">Product Focus</h2>
	    <span class="shadow-head"><img src="'. get_bloginfo(template_url).'/assets/img/shadow.png" height="20" alt=""></span>
	  </div>';
	echo do_shortcode('[wpb-latest-product title="Latest Product"]');
	echo '</div>';

	//News
	include('news.php');
?>

<?php
	//Footer
	include('footer.php');
?>