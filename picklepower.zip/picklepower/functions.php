<?php 
// Register Custom Navigation Walker
require_once('navigation.php');
add_action( 'after_setup_theme', 'register_my_menu' );
function register_my_menu() {
  register_nav_menu( 'primary', __( 'Header Menu', 'picklepower' ) );
}

//Register Widget
function arphabet_widgets_init() {

	register_sidebar( array(
		'name'          => 'Sidebar',
		'id'            => 'sidebar',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => 'Footer 1',
		'id'            => 'footer-1',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => 'Footer 2',
		'id'            => 'footer-2',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => 'Footer 3',
		'id'            => 'fooer-3',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => 'Footer 4',
		'id'            => 'footer-4',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => 'Mail Subscription',
		'id'            => 'mail-subscription',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'arphabet_widgets_init' );

// Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');

//Advanced Custom Fields PRO Update disabled
add_filter('site_transient_update_plugins', 'my_remove_update_nag');
function my_remove_update_nag($value) {
 unset($value->response[ 'advanced-custom-fields-pro/acf.php' ]);
 return $value;
}

// Theme Options
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/include/Core/framework.php' ) ) {
    require_once( dirname( __FILE__ ) . '/include/Core/framework.php' );
}
if ( !isset( $picklepower ) && file_exists( dirname( __FILE__ ) . '/include/theme-core/theme-options.php' ) ) {
    require_once( dirname( __FILE__ ) . '/include/theme-core/theme-options.php' );
}

//Woocpmmerce Custom Template include Shop Page
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_action('woocommerce_before_shop_loop_item','add_image_wrapper',9);
function add_image_wrapper()
{
	echo '<div class="product-item">' ;
}
add_action( 'woocommerce_after_shop_loop_item', 'image_wrapper_open', 11 );
function image_wrapper_open(){
	echo '</div>';
}
// Remove Product Link
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
//remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash' , 10 );

add_action( 'woocommerce_before_shop_loop_item_title', 'image_new_wrapper', 9);
function image_new_wrapper()
{
echo '<div class="pi-img-wrapper">';
}
add_action( 'woocommerce_shop_loop_item_title', 'image_wrapper_close', 5);
function image_wrapper_close()
{
	echo '<div>
	         <a href="'.get_permalink().'" class="btn">View Product</a>
	      </div>
	     </div>' ;

}
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );

//Single Product Page

//remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );

/**
 * These functions will add WooCmmerce or Easy Digital Downloads cart icons/menu items to the "top_nav" WordPress menu area (if it exists).
 * Please customize the following code to fit your needs.
 */
 
/**
 * This function adds the WooCommerce or Easy Digital Downloads cart icons/items to the top_nav menu area as the last item.
 */
add_filter( 'wp_nav_menu_items', 'my_wp_nav_menu_items', 10, 2 );
function my_wp_nav_menu_items( $items, $args, $ajax = false ) {
	// Top Navigation Area Only
	if ( ( isset( $ajax ) && $ajax ) || ( property_exists( $args, 'theme_location' ) && $args->theme_location === 'top_nav' ) ) {
		// WooCommerce
		if ( class_exists( 'woocommerce' ) ) {
			$css_class = 'menu-item menu-item-type-cart menu-item-type-woocommerce-cart';
			// Is this the cart page?
			if ( is_cart() )
				$css_class .= ' current-menu-item';
			$items .= '<li class="' . esc_attr( $css_class ) . '">';
				$items .= '<a class="cart-contents" href="' . esc_url( WC()->cart->get_cart_url() ) . '">';
					$items .= wp_kses_data( WC()->cart->get_cart_total() ) . ' - <span class="count">' .  wp_kses_data( sprintf( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count(), 'simple-shop' ), WC()->cart->get_cart_contents_count() ) ) . '</span>';
				$items .= '</a>';
			$items .= '</li>';
		}
		// Easy Digital Downloads
		else if ( class_exists( 'Easy_Digital_Downloads' ) ) {
			$css_class = 'menu-item menu-item-type-cart menu-item-type-edd-cart';
			// Is this the cart page?
			if ( edd_is_checkout() )
				$css_class .= ' current-menu-item';
			$items .= '<li class="' . esc_attr( $css_class ) . '">';
				$items .= '<a class="cart-contents" href="' . esc_url( edd_get_checkout_uri() ) . '">';
					$items .= wp_kses_data( edd_cart_subtotal() ) . ' - <span class="count">' .  wp_kses_data( sprintf( _n( '%d item', '%d items', edd_get_cart_quantity(), 'simple-shop' ), edd_get_cart_quantity() ) ) . '</span>';
				$items .= '</a>';
			$items .= '</li>';
		}
	}
	return $items;
}
/**
 * This function updates the Top Navigation WooCommerce cart link contents when an item is added via AJAX.
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'my_woocommerce_add_to_cart_fragments' );
function my_woocommerce_add_to_cart_fragments( $fragments ) {
	// Add our fragment
	$fragments['li.cart-item'] = my_wp_nav_menu_items( '', new stdClass(), true );
	return $fragments;
}