<div class="container">
  <div class="row">
    <h2 class="sec_head">News</h2>
    <span class="shadow-head"><img src="<?php bloginfo(template_url); ?>/assets/img/shadow.png" height="20" alt=""></span>
  </div>
</div>
<div class="container">
	<div class="row">
		<!-- Loop -->

		<?php
			$args = array('posts_per_page' => 6);
				$query = new WP_Query( $args );
					while( $query->have_posts()) : $query->the_post();
						?>
		<div class="col-md-4 animated fadeIn">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( '', array( 'class' => 'img-responsive animated fadeIn' ) ); ?></a>
			<h4 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		</div>	

		<?php 
			endwhile
				?>
		<!-- End Loop -->
	</div>
</div>