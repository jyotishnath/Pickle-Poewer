<?php 
	/*
	* Template Name: FAQ
	*/
	//Header
	get_header();
?>

<div class="container-fluid no-pading page-banner">
	<a href="javascript:void(0);">
		<?php 
			if(get_field("page_header_image")){				
				echo '<img src="'. get_field("page_header_image").'" alt="">' ;
			}
			else
			{
				echo "";
			}
		?>
	</a>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<!-- Loop -->
			<?php
				if ( have_posts() ) {
					while ( have_posts() ) {
						the_post(); 
							?>
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home /</a></li>
					<li><?php the_title(); ?></li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1><?php the_title(); ?></h1>
				

			<!-- Accordian -->
          <div class="accordion">
			
			<dl>
				<?php

					// check if the repeater field has rows of data
					if(get_field('faq')): $i = 0;
						while(has_sub_field('faq')): $i++;
					 	// loop through the rows of data
				echo	'<ul>';
						echo '<li class="'.$i.'">';
				echo '<dt>';
					echo '<a href="#accordion1" aria-expanded="false" aria-controls="accordion1" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> '. get_sub_field("question") .'</a>';

				echo '</dt>';

				echo '<dd class="accordion-content accordionItem is-collapsed" id="accordion1" aria-hidden="true">';
					        // display a sub field value
					echo '<p><span class="yellow-text">A: </span>' . get_sub_field("answer"). '</p>';

				echo '</dd>';
						echo '</li>';
				echo '</ul>';
					    endwhile;

					else :

					    // no rows found

					endif;

				?>
			</dl>
          </div>
				<!-- End Accordian -->

			</div>
			<div class="col-md-3 page-content">
				<h3><?php //widget_title(); ?></h3>
				<?php dynamic_sidebar( 'sidebar' ); ?>
			</div>
			<?php 
				} // end while
					} // end if
						?>
			<!-- End Loop -->
		</div>
	</div>
</div>

<?php
	//Footer
	get_footer();
?>