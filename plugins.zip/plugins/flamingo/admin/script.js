(function($) {

$(function() {
	postboxes.add_postbox_toggles(_flamingo.screenId);
});

})(jQuery);